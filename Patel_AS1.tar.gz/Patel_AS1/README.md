Name: Nirmit Patel
CS 381 
Assignment 1
February 22, 2017

Cubes Controls: 
Numpad 8/2: move in z direction
Numpad 4/6: move in x direction
Numpad 9/3 or PGUP/PGDOWN: move in y direction
SPACE: Stopes all the movements

If TAB pressed, moves only the second cube (wood textured), otherwise moves the first cube (borg textured)

Camera Cotrols: 
W/S: move in z direction
A/D: move in x direction
E/F: move in y direction


Extra Credit Attempt: 
1. Textures to both cubes
2. Have multiple cubes controlled by numpad keys and TAB key



/*
 * As2.h
 *
 *  Created on: Jan 24, 2017
 *      Author: sushil
 */

#ifndef __As2_h_
#define __As2_h_


#include "../Inc/engine.h"

class As3 {
private:

public:
  As3();
  ~As3();


};

#endif // #ifndef __As2_h_

/*
 * mgr.cpp
 *
 *  Created on: Mar 9, 2017
 *      Author: sushil
 */

#include "../Inc/mgr.h"

Mgr::Mgr(Engine *eng){
	engine = eng;
}
Mgr::~Mgr(){
}
void Mgr::tick(float dt){
}
void Mgr::init(){
}
void Mgr::loadLevel(){
}
void Mgr::stop(){
}
